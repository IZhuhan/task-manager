// // Module pattern
// const Module = (function () {
//     // Function body
//
//     return {
//         // methods
//     };
// })();
//
// // Singleton pattern
// const counterModule = ( function () {
//     let instance,
//         counter = 0;
//
//     const getCounter = function () {
//         return counter;
//     };
//
//     const increaseCounter = function () {
//         counter++;
//     };
//
//     const createInstance = function () {
//         return {
//             getCounter,
//             increaseCounter
//         }
//     };
//
//     return {
//         getInstance: function () {
//             return instance || ( instance = createInstance() );
//         }
//     }
// } )();
//
// const counter1 = counterModule.getInstance();
// const counter2 = counterModule.getInstance();
//
// // Factory pattern
//   class SimpleMemberShip {
//       constructor( name ) {
//           this.name = name;
//           this.cost = '$5';
//       }
//   }
//
//   class StandardMemberShip {
//       constructor( name ) {
//           this.name = name;
//           this.cost = '$15';
//       }
//   }
//
//   class SuperMemberShip {
//       constructor( name ) {
//           this.name = name;
//           this.cost = '$25';
//       }
//   }
//
//   function MemberFactory() {
//       this.createMember = function ( name, type ) {
//           let member;
//
//           if ( type === 'simple' ) {
//               member = new SimpleMemberShip( name );
//           } else if ( type === 'standard' ) {
//               member = new StandardMemberShip( name );
//           } else if ( type === 'super' ) {
//               member = new SuperMemberShip( name );
//           }
//
//           member.type = type;
//
//           member.define = function () {
//               return `${ this.name } ( ${ this.type } ): ${ this.cost }`;
//           };
//
//           return member;
//       }
//   }
//
//   const members = [];
//   const factory = new MemberFactory();
//
//   members.push( factory.createMember( 'Ira', 'standard' ) );
//   members.push( factory.createMember( 'Maksim', 'standard' ) );
//   members.push( factory.createMember( 'Artem', 'simple' ) );
//
//   // const ira = new SimpleMemberShip( 'Ira' );
//   // ira.type = 'simple';
//   // ira.define = function () {
//   //     return `${ this.name } ( ${ this.type } ): ${ this.cost }`;
//   // };
//
// // Observer pattern
// class EventObserver {
//     constructor() {
//         // Subscribers array
//         this.observers = [];
//     }
//
//     // subscribe on event
//     subscribe( fn ) {
//         this.observers.push( fn );
//     }
//
//     // unsubscribe off of event
//     unsubscribe( fn ) {
//         this.observers = this.observers.filter( item => {
//             if ( item !== fn ) return item;
//         })
//     }
//
//     fire( args ) {
//         this.observers.forEach( fh => fn.call( null, args ) );
//     }
// }
//
// // const ev = new EventObserver();
// //
// // function fn1() {
// //     console.log( 'heloo ira');
// // }
// //
// // function fn2() {
// //     console.log( ' ira hello');
// // }
// //
// // ev.subscribe( fn1 );
// // ev.subscribe( fn2 );
// //
// // ev.unsubscribe( fn2 );
//
// const addNewTask = new EventObserver();
//
// function alertMessage( msg ) {
//     alert( msg );
// }
//
// function consoleMessage( msg ) {
//     console.log( msg );
// }
//
// addNewTask.subscribe( alertMessage );
// addNewTask.subscribe( consoleMessage );
//
// // addNewTask.fire( 'new message' );
//
// // Mediator pattern
// class User{
//     constructor( name ) {
//         this.name = name;
//         this.chatroom = null;
//     }
//
//     send( message, to ) {
//         // call method send at chatroom
//         this.chatroom.send( message, this, to );
//     }
//
//     receive( message, from ) {
//         console.log( `From ${ from.name } to ${ this.name }: ${ message }`);
//     }
// }
//
// class ChatRoom {
//     constructor() {
//         this.users = {};
//     }
//
//     register( user ) {
//         user.chatroom = this;
//         this.users[ user.name ] = user;
//     }
//
//     send( message, from, to ) {
//         // broadcast event
//         if ( to ) {
//             // single user message
//             to.receive( message, from );
//         } else {
//             // mass message
//             for ( let user in this.users ) {
//                 if ( this.users[ user ] !== from ) {
//                     this.users[ user ].receive( message, from );
//                 }
//             }
//         }
//     }
// }
//
// // Create users
// const ira = new User( 'Ira' );
// const olga = new User( 'Olga' );
// const maksim = new User( 'Maksim' );
//
// // Create chatroom
// const chatroom = new ChatRoom();
//
// // register users
// chatroom.register( ira );
// chatroom.register( olga );
// chatroom.register( maksim );

const todoList = (function () {
    let tasks = JSON.parse( localStorage.getItem( 'tasks' ) ) || [];
    const form = document.forms[ 'addTodoItem' ];
    const inputText = form.elements[ 'todoText' ];
    const ul = document.querySelector( '.list-group' );
    const clearBtn = document.querySelector( '.clear-btn' );
    const alert = document.querySelector( '.alert' );
    let timeoutID;

    function init() {
        generateList( tasks );
    }

    form.addEventListener( 'submit', function ( e ) {
        e.preventDefault();

        if ( !inputText.value ) {
            inputText.classList.add( 'is-invalid' );
        } else {
            inputText.classList.remove( 'is-invalid' );

            addListItem({
                id: generateId(),
                title: inputText.value,
                completed: false
            });

            generateList( tasks );

            addAlert({
                class: 'alert-success',
                timeout: 1000,
                text: 'Task added success!'
            });

            form.reset();
        }
    });

    inputText.addEventListener( 'keyup', function () {
        if ( inputText.value ) {
            inputText.classList.remove( 'is-invalid' );
        }
    });

    ul.addEventListener( 'click', function ( e ) {
        let parent = e.target.closest( 'li' );
        let id = parent.dataset.id;

        if ( e.target.classList.contains( 'checkbox' ) ) {
            let input = parent.querySelector( 'input' );

            input.checked = !input.checked;

            parent.classList.toggle( 'bg-success' );
            editListItem( id, input.checked, 'completed' );

            addAlert({
                class: 'alert-primary',
                timeout: 1000,
                text: 'Task execution has been changed!'
            });
        } else if ( e.target.classList.contains( 'delete-item' ) ) {
            addAlert({
                class: 'alert-danger',
                timeout: 1000,
                text: 'Task has been removed success!'
            });

            parent.remove();
            deleteListItem( id );
        } else if ( e.target.classList.contains( 'edit-item' ) ) {
            e.target.classList.toggle( 'fa-save' );

            let span = parent.querySelector( 'span' );

            if ( e.target.classList.contains( 'fa-save' ) ) {
                span.setAttribute( 'contenteditable', 'true' );
                span.focus();
            } else {
                span.setAttribute( 'contenteditable', 'false' );

                editListItem( id, span.textContent, 'title' );

                addAlert({
                    class: 'alert-warning',
                    timeout: 1000,
                    text: 'Task has been edited success!'
                });

                span.blur();
            }
        }
    });

    clearBtn.addEventListener( 'click', function () {
        tasks.splice( 0, tasks.length );

        localStorage.setItem( 'tasks', JSON.stringify( tasks ) );

        generateList( tasks );
    });

    function addAlert( settings ) {
        clearTimeout( timeoutID );

        alert.className = 'alert mb-0';
        alert.textContent = settings.text;
        alert.classList.add( settings.class, 'show');

        if ( settings.timeout !== 'none' ) {
            alert.classList.add( 'fixed' );

            timeoutID = setTimeout( () => {
                alert.classList.add( 'opacity' );

                alert.addEventListener( 'transitionend', () => {
                    alert.className = 'alert';
                });
            }, settings.timeout );
        }
    }

    function checkState() {
        if ( !tasks.length ) {
            addAlert({
                class: 'alert-info',
                timeout: 'none',
                text: 'Empty list.'
            });
        } else if ( alert.classList.contains( 'alert-info' ) ) {
            alert.className = 'alert';
        }
    }

    function generateId() {
        let id = '';
        let words = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';

        for ( let i = 0; i < 15; i++ ) {
            let position = Math.floor( Math.random() * words.length );
            id += words[position];
        }

        return id;
    }

    function listTemplate( task ) {
        return `<li class="list-group-item d-flex align-items-center${ task.completed ? ' bg-success' : '' }" data-id=${ task.id }>
                    <input class="checkbox" type="checkbox" id="completed-${ task.id }" ${ task.completed ? 'checked' : '' }>
                    <div class="d-flex align-self-center checkbox mb-0">
                        <span class="checkbox">${ task.title }</span>
                    </div>
                    <i class="fas fa-edit edit-item ml-auto"></i>
                    <i class="fas fa-trash-alt delete-item ml-4"></i>
                </li>`;
    }

    function clearList() {
        ul.innerHTML = '';
    }

    function generateList( tasksArray ) {
        clearList();
        checkState();

        for ( let i = 0; i < tasksArray.length; i++ ) {
            ul.insertAdjacentHTML( 'afterbegin', listTemplate( tasksArray[i] ) );
        }
    }

    function addListItem( list ) {
        tasks.push( list );

        localStorage.setItem( 'tasks', JSON.stringify( tasks ) );
    }

    function deleteListItem( id ) {
        for ( let i = 0; i < tasks.length; i++ ) {
            if ( tasks[i].id === id ) {
                tasks.splice( i, 1 );
                break;
            }
        }

        checkState();

        localStorage.setItem( 'tasks', JSON.stringify( tasks ) );
    }

    function editListItem( id, newValue, fieldName ) {
        for (let i = 0; i < tasks.length; i++) {
            if ( tasks[i].id === id ) {
                tasks[i][fieldName] = newValue;
                break;
            }
        }

        localStorage.setItem( 'tasks', JSON.stringify( tasks ) );
    }

    return {
        init: init
    }
})();

todoList.init();